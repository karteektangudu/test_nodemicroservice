sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/ODataModel"

], function(Controller, JSONModel, ODataModel) {
	"use strict";

	return Controller.extend("demo.crudcrudOperations.controller.View2", {

		onInit: function() {

			var json = new JSONModel();
			sap.ui.getCore().setModel(json, "viewModel");
			// this.bModel = new JSONModel({
			// 	editable: false,
			// 	save: false,
			// 	edit: true,
			// 	cancel: false,
			// 	close: true
			// });
			// this.getView().setModel(this.bModel, "buttonModel");
			// this.oModel1.setDefaultBindingMode("OneWay");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("View2").attachPatternMatched(this._onObjectMatched, this);
			// var tData = sap.ui.getCore().getModel().getData();
		},

		_onObjectMatched: function(oEvent) {
			this.a = oEvent.getParameter("arguments").index;
			var that = this;
			// var k = sap.ui.getCore().getModel().getData();
			this.oModel = JSON.parse(JSON.stringify(sap.ui.getCore().getModel().getData()));
			// this.oModel = k;
			// this.oModel = sap.ui.getCore().getModel().getData();

			// this.oModel10 = this.oModel;

			//oModel.attachRequestCompleted(function() {
			// var oData1 = sap.ui.getCore().getModel().getData();
			this.oModel1 = new JSONModel(this.oModel.employees[this.a]);
			// this.oModel1.setDefaultBindingMode("OneWay");
			that.getView().setModel(this.oModel1, "viewModel");
			// this.oModel22 = new JSONModel(this.oModel.employees[this.a]);
			// // this.oModel1.setDefaultBindingMode("OneWay");
			// that.getView().setModel(this.oModel1, "viewModel22");

			this.bModel = new JSONModel({
				editable: false,
				save: false,
				edit: true,
				cancel: false,
				close: true
			});
			this.getView().setModel(this.bModel, "buttonModel");

		},
		onEditView2: function() {
			// this.bModel = new JSONModel({
			// 	editable: true
			// });
			// this.getView().setModel(this.bModel, "buttonModel");
			this.getView().getModel("buttonModel").setProperty("/editable", true);
			this.getView().getModel("buttonModel").setProperty("/edit", false);

			this.getView().getModel("buttonModel").setProperty("/close", false);
			this.getView().getModel("buttonModel").setProperty("/save", true);
			this.getView().getModel("buttonModel").setProperty("/cancel", true);
			// var edit = this.getView().byId("Edit");
			// if (edit.getVisible()) {
			// 	edit.setVisible(false);
			// }
			// var save = this.getView().byId("Save");
			// if (!save.getVisible()) {
			// 	save.setVisible(true);
			// }
			// var cancel = this.getView().byId("Cancel");
			// if (!cancel.getVisible()) {
			// 	cancel.setVisible(true);
			// }
			// var close = this.getView().byId("Close");
			// if (close.getVisible()) {
			// 	close.setVisible(false);
			// }

		},
		onSaveBack: function() {

			// this.bModel = new JSONModel({
			// 	editable: false
			// });
			// this.getView().setModel(this.bModel, "buttonModel");
			// var edit = this.getView().byId("Edit");
			// if (!edit.getVisible()) {
			// 	edit.setVisible(true);
			// }
			// var close = this.getView().byId("Close");
			// if (!close.getVisible()) {
			// 	close.setVisible(true);
			// }
			// var save = this.getView().byId("Save");
			// if (save.getVisible()) {
			// 	save.setVisible(false);
			// }
			// var cancel = this.getView().byId("Cancel");
			// if (cancel.getVisible()) {
			// 	cancel.setVisible(false);
			// }

			// var data = sap.ui.getCore().getModel().getData();
			// var jModel = new JSONModel(data);
			// sap.ui.getCore().byId("__xmlview1--table").setModel(jModel);

			//array(employees) table
			var vData = this.getView().getModel("viewModel").getData(); //object form
			// this.oModel.employees[this.a].id = vData.id;
			// this.oModel.employees[this.a].Name = vData.Name;
			// this.oModel.employees[this.a].Designation = vData.Designation;
			// this.oModel.employees[this.a].Salary = vData.Salary;
			this.oModel.employees[this.a] = vData;
			sap.ui.getCore().getModel().setData(this.oModel);

			this.getView().getModel("buttonModel").setProperty("/editable", false);
			this.getView().getModel("buttonModel").setProperty("/edit", true);

			this.getView().getModel("buttonModel").setProperty("/close", true);
			this.getView().getModel("buttonModel").setProperty("/save", false);
			this.getView().getModel("buttonModel").setProperty("/cancel", false);
		},
		onCancelBack: function() {

			// this.bModel = new JSONModel({
			// 	editable: false
			// });
			// this.getView().setModel(this.bModel, "buttonModel");
			// var edit = this.getView().byId("Edit");
			// if (!edit.getVisible()) {
			// 	edit.setVisible(true);
			// }
			// var close = this.getView().byId("Close");
			// if (!close.getVisible()) {
			// 	close.setVisible(true);
			// }
			// var save = this.getView().byId("Save");
			// if (save.getVisible()) {
			// 	save.setVisible(false);
			// }
			// var cancel = this.getView().byId("Cancel");
			// if (cancel.getVisible()) {
			// 	cancel.setVisible(false);

			// }

			this.getView().getModel("buttonModel").setProperty("/editable", false);
			this.getView().getModel("buttonModel").setProperty("/edit", true);

			this.getView().getModel("buttonModel").setProperty("/close", true);
			this.getView().getModel("buttonModel").setProperty("/save", false);
			this.getView().getModel("buttonModel").setProperty("/cancel", false);

			var oModel = JSON.parse(JSON.stringify(sap.ui.getCore().getModel().getData()));
			this.getView().getModel("viewModel").setData(oModel.employees[this.a]);
		},
		onCloseBack: function() {

				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("View1");

			}
			// onSaveBack: function(oEvent) {
			// 	var vModel = this.getView().getModel("viewModel").getData();
			// 	var tModel = sap.ui.getCore().byId("table");
			// 	var selectRow = tModel.getSelectedItem();

	});
});