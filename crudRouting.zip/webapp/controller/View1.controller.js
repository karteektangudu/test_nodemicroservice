sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/Token"

], function(Controller, JSONModel, MessageBox, Filter, FilterOperator, Token) {
	"use strict";

	return Controller.extend("demo.crudcrudOperations.controller.View1", {

		onInit: function() {

			this.data = {
				employees: []

			};
			var oModel = new JSONModel(this.data);
			this.getView().setModel(oModel);
			sap.ui.getCore().setModel(oModel);
			var oView = this.getView();
			var oMultiInput1 = oView.byId("multiInput1");
			var oMultiInput2 = oView.byId("multiInput2");

			// var oCheckBox = oView.byId("checkbox1");
			// var oCheckBox2 = oView.byId("checkbox2");

			var inputModel = new JSONModel({
				selectedValues: [],
				selectedNames: [],
				selectedCombo: []
			});
			this.getView().setModel(inputModel, "inputModel");

			var comboModel = new JSONModel("model/combo.json");
			this.getView().setModel(comboModel, "comboModel");

			// oMultiInput1.addValidator(function(args) {
			// 	if (oCheckBox.getSelected()) {
			// 		var text = args.text;
			// 		return new Token({
			// 			key: text,
			// 			text: text
			// 		});
			// 	}
			// });
			// oMultiInput2.addValidator(function(args) {
			// 	if (oCheckBox2.getSelected()) {
			// 		var text = args.text;
			// 		return new Token({
			// 			key: text,
			// 			text: text
			// 		});
			// 	}
			// });
			var fnValidator = function(args) {
				var text = args.text;

				return new Token({
					key: text,
					text: text
				});
			};
			oMultiInput1.addValidator(fnValidator);
			oMultiInput2.addValidator(fnValidator);
			// oMultiInput1.addValidator(function(args) {
			// 	if (args.suggestedToken) {
			// 		var text = args.suggestedToken.getText();
			// 		return new Token({
			// 			key: text,
			// 			text: text
			// 		});
			// 	}
			// });
			// oMultiInput2.addValidator(function(args) {
			// 	if (args.suggestedToken) {
			// 		var text = args.suggestedToken.getText();
			// 		return new Token({
			// 			key: text,
			// 			text: text
			// 		});
			// 	}
			// });

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("View1").attachPatternMatched(this.object, this);
		},
		object: function() {
			var data = sap.ui.getCore().getModel().getData();
			if (data.employees.length !== 0) {
				this.getView().getModel().setData(data);
			}

			// var data = sap.ui.getCore().getModel();
			// if (data !== undefined) {
			// 	this.getView().getModel().setData(data);
			// }

			// var viewModel = new JSONModel({
			// 	"visible": true
			// });
			// this.getView().setModel(viewModel, "viewModel");
		},
		onSubmit: function(oEvent) {
			var tokens = this.getView().byId("multiInput1").getTokens();
			var sData = tokens.map(function(oToken) {
				return oToken.getKey();
			});
			this.getView().getModel("inputModel").setProperty("/selectedValues", sData);
		},
		onSubmit2: function(oEvent) {
			var tokens2 = this.getView().byId("multiInput2").getTokens();
			var sData2 = tokens2.map(function(oToken2) {
				return oToken2.getKey();
			});
			this.getView().getModel("inputModel").setProperty("/selectedNames", sData2);
		},
		onSelectionChange22: function(oEvent) {
			var that = this;
			var selValues22 = oEvent.getSource().getSelectedKeys();
			that.getView().getModel("inputModel").setProperty("/selectedCombo", selValues22);
		},

		onGo: function() {
			var that = this,
				mainFilters = [],
				Filters = [];
			var multiInputs = that.getView().getModel("inputModel").getProperty("/selectedValues");
			multiInputs.forEach(function(item) {
				Filters.push(new Filter("id", FilterOperator.EQ, item));
			});
			var oNewFilter = new Filter({
				filters: Filters,
				and: false
			});
			mainFilters.push(oNewFilter);
			that.getView().byId("table").getBinding("items").filter(oNewFilter);

			//second MultiInput

			var Filters2 = [];
			var multiInputs2 = that.getView().getModel("inputModel").getProperty("/selectedNames");

			multiInputs2.forEach(function(item) {
				Filters2.push(new Filter("Name", FilterOperator.EQ, item));
			});

			var oNewFilter22 = new Filter({
				filters: Filters2,
				and: false
			});
			mainFilters.push(oNewFilter22);
			that.getView().byId("table").getBinding("items").filter(oNewFilter22);

			//MultiCombo
			var Filters3 = [];
			var multiCombo = that.getView().getModel("inputModel").getProperty("/selectedCombo");

			multiCombo.forEach(function(item) {
				Filters3.push(new Filter("Designation", FilterOperator.EQ, item));
			});

			var oNewFilter33 = new Filter({
				filters: Filters3,
				and: false
			});
			mainFilters.push(oNewFilter33);
			that.getView().byId("table").getBinding("items").filter(oNewFilter33);

			//Single Input
			var oTable = this.getView().byId("table");
			var SearchVal = this.getView().byId("inputId").getValue();
			var Filters5 = [];
			Filters5.push(new Filter({
				path: "Salary",
				operator: FilterOperator.EQ,
				value1: SearchVal
			}));
			var oNewFilter5 = new Filter({
				filters: Filters5,
				and: false
			});
			mainFilters.push(oNewFilter5);

			var sMainFilters = [new Filter({
				filters: mainFilters,
				and: false
			})];
			that.getView().byId("table").getBinding("items").filter(sMainFilters);
			oTable.getBinding("items").filter(oNewFilter5);
		},

		// onAfterRendering: function() {
		// 	var oModel = new JSONModel(this.data);
		// 	this.getView().setModel(oModel);
		// },

		onAdd: function() {
			var ddData = {
				id: "",
				Name: "",
				Designation: "",
				Salary: ""
			};
			var oModel = new JSONModel(ddData);
			this.getView().setModel(oModel, "dialogModel");
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("demo.crudcrudOperations.view.Fragment",this);
				this.getView().addDependent(this.oDialog);

			}
			// this.oDialog.getModel("dialogModel").setData(this.employee);
			this.oDialog.open();
		},
		onSave: function(oEvent) {

			var oModel = this.getView().getModel("dialogModel");
			var oData = oModel.getData();

			var viewData = sap.ui.getCore().getModel().getData();
			viewData.employees.push(oData);
			sap.ui.getCore().getModel().setData(viewData);
			this.getView().getModel().setData(viewData);
			sap.ui.getCore().getModel().updateBindings(true);
			this.oDialog.close();

			// console.log(oData);
			// var oEdit = oEvent.getSource().getBindingContext().getObject();
			// console.log(oEdit);

		},
		onDelete: function(oEvent) {
			// MessageBox.confirm("Data will be deleted");
			// alert("delete");
			var viewData22 = sap.ui.getCore().getModel().getData();

			// console.log(viewData22.employees);
			// this.getView().byId("inp1");
			var oDelete = oEvent.getSource().getBindingContext().getPath();
			var idx = oDelete.split("/")[2];
			// console.log(oDelete);
			// var id = oDelete.id;
			// console.log(id);
			// var idx = viewData22.employees.findIndex(function(index) {
			// 	return index.id === id;
			// });

			viewData22.employees.splice(idx, 1);
			// console.log(viewData22.employees);
			sap.ui.getCore().getModel().setData(viewData22).updateBindings(true);
			//this.employees.splice(index,1);

			// var viewData = this.getView().byId("inp1").getValue();
			//	console.log(viewData);

		},
		onDeleteRows: function(oEvent) {
			// MessageBox.confirm("Data will be deleted");
			// alert("delete");
			var viewData22 = sap.ui.getCore().getModel().getData();
			var tData = this.getView().byId("table");
			// console.log(viewData22.employees);
			// viewData22.byId("inp1");
			// var oDelete = oEvent.getSource().getBindingContext().getPath();

			// var id = oDelete.id;
			// console.log(id);
			// var idx = viewData22.employees.findIndex(function(index) {
			// 	return index.id === id;
			// });
			var items = tData.getSelectedItems();

			for (var i = items.length - 1; i >= 0; --i) {
				var path = items[i].getBindingContext().getPath();
				var Index = path.split("/")[2];
				// var Index = aPathParts[aPathParts.length - 1];
				var oJSONData = sap.ui.getCore().getModel().getData();
				oJSONData.employees.splice(Index, 1);
				sap.ui.getCore().getModel().setData(oJSONData);

				// viewData22.emplolyees.splice(idx, 1);
			}
			// var oDelete = oEvent.getSource().getBindingContext().getPath();
			// var idx = oDelete.split("/")[2];
			// viewData22.employees.splice(idx, 1);
			// console.log(viewData22.employees);
			// this.getView().getModel().setData(viewData22);
			//this.employees.splice(index,1);

			// var viewData = this.getView().byId("inp1").getValue();
			//	console.log(viewData);

		},
		// onDeleteRows: function(oEvent) {
		// 	var that = this;
		// 	var oTable = this.getView().getModel().getData();
		// 	// var oModel = that.getView().getModel();
		// 	// var data = oModel.getData();
		// 	// //
		// 	var oDeleteRows = oTable.getPath();
		// 	var idx = oDeleteRows.split("/")[2];

		// 	//

		// 	// oTable.setData(del);

		// },
		onEdit: function(oEvent) {

			// this.oDialog.getModel("dialogModel").setData(this.employee);
			var onRead = oEvent.getSource().getBindingContext().getObject();
			onRead.editable = false;
			var Model = new JSONModel(onRead);

			this.getView().setModel(Model, "dialogModel");
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("demo.crudcrudOperations.view.Fragment", this);
				this.getView().addDependent(this.oDialog);

			}
			// this.oDialog.getModel("dialogModel").setData(this.employee);
			this.oDialog.open();
			//	 console.log(viewData22.employees);
			// var oUpdate = oEvent.getSource().getBindingContext().getObject();

			// console.log(oUpdate);
			// var id = oUpdate.id;
			// var name = oUpdate.Name;
			// var designation = oUpdate.Designation;
			// var salary = oUpdate.Salary;
			// console.log(name);
			// console.log(designation);
			// console.log(salary)
			////   console.log(id);
			//var data = viewData22.employees.filter(function (data){return data.id === id;});
			//console.log(data)

			// var oModel = this.getView().getModel("dialogModel");
			// var oData = oModel.setData(oUpdate);
			//	console.log()
		},
		onClose: function() {
			this.oDialog.close();
			this.oDialog.destroy();
			this.oDialog = null;
		},
		onUpdate: function(oEvent) {
			var onRead = oEvent.getSource().getBindingContext().getObject();
			onRead.editable = true;
			var Model = new JSONModel(onRead);
			this.onRead = oEvent.getSource().getBindingContext();
			var Model = new JSONModel(this.onRead.getObject());

			this.getView().setModel(Model, "dialogModel");
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("demo.crudcrudOperations.view.Fragment", this);
				this.getView().addDependent(this.oDialog);

			}
			// this.oDialog.getModel("dialogModel").setData(this.employee);
			this.oDialog.open();

		},
		onUpdateRow: function(oEvent) {
			// var table = oEvent.getSource().getParent().getParent().getBindingContextPath().split("/")[2];

			var data = sap.ui.getCore().getModel();
			var sPath = this.onRead.getPath();
			var oValue = this.getView().getModel("dialogModel").getData();
			data.setProperty(sPath, oValue, this.onRead, true);

		},
		onPress: function(oEvent) {
			// var oItem = oEvent.getSource();
			// var sObj = oItem.getBindingContext().getObject();
			// this.getView().getModel("dialogModel");
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View2", {
				index: sPath.split("/")[2]
			});
		},

		onSearch: function(oEvent) {
			var value = oEvent.getSource().getValue();
			var oTable = this.getView().byId("table");
			var Items = oTable.getBinding("items");
			var oFilters = [];
			oFilters.push(new Filter({
				path: "Name",
				operator: FilterOperator.Contains,
				value1: value
			}));
			oFilters.push(new Filter({
				path: "id",
				operator: FilterOperator.Contains,
				value1: value
			}));
			var Filters = [new Filter({
				filters: oFilters,
				and: false
			})];
			Items.filter(Filters);
		},
		onSearch22: function() {

		}

	});
});